# Mis peliculas

Vamos a gestionar un listado de películas que guardaremos en un fichero de texto. El programa principal nos permitirá:

1.- Añadir una peli.
2.- Borrar una peli.
3.- Mostrar todas.
4.- Salir del programa.

De las películas guardaremos: título, director, duración y año. 
