interface PeliculaFichero {
    fun addPelicula(): Pelicula
    fun deletePelicula(): Pelicula
}